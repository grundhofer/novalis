# Projekt Übersicht

See [Aufgaben](Aufgaben%200123456789abcdef0123456789abcdef.csv) and [Milch kaufen](Aufgaben%200123456789abcdef0123456789abcdef/Milch%20kaufen%20fedcba9876543210fedcba9876543210.md).

![Diagramm](Projekt%20%C3%9Cbersicht%201a2b3c4d5e6f70819a2b3c4d5e6f7081/diagram.png)
